from datetime import datetime

class Vehiculo:
    _contador_vehiculos = 0

    def __init__(self, marca, modelo, año, precio_base):
        self.marca = marca
        self.modelo = modelo
        self.año = año
        self.precio_base = precio_base
        self._encendido = False
        self._disponible = True
        Vehiculo._contador_vehiculos += 1
        print(f"🚗 Vehículo registrado: {self.marca} {self.modelo} ({self.año})")

    def __del__(self):
        print(f"🗑️ {self.marca} {self.modelo} ha sido dado de baja.")
        Vehiculo._contador_vehiculos -= 1

    def encender(self):
        if not self._encendido:
            self._encendido = True
            print(f"🔑 {self.marca} {self.modelo}: Motor encendido.")
        else:
            print(f"{self.marca} {self.modelo} ya estaba encendido.")

    def apagar(self):
        if self._encendido:
            self._encendido = False
            print(f"🔒 {self.marca} {self.modelo}: Motor apagado.")
        else:
            print(f"{self.marca} {self.modelo} ya estaba apagado.")

    def calcular_alquiler(self, tiempo):
        raise NotImplementedError("Este método debe ser redefinido en las clases derivadas.")

    def mostrar_info(self):
        estado = "Encendido" if self._encendido else "Apagado"
        disponibilidad = "Disponible" if self._disponible else "No disponible"
        print(f"{self.marca} {self.modelo} ({self.año}) - Precio base: {self.precio_base}")
        print(f"Estado: {estado} | Disponibilidad: {disponibilidad}")

    @classmethod
    def total_vehiculos(cls):
        return cls._contador_vehiculos

    @staticmethod
    def validar_año(año):
        actual = datetime.now().year
        return 1900 < año <= actual

    @staticmethod
    def validar_precio(precio):
        return precio > 0

    @property
    def encendido(self):
        return self._encendido

    @property
    def disponible(self):
        return self._disponible


class Coche(Vehiculo):
    def __init__(self, marca, modelo, año, precio_base, num_puertas):
        super().__init__(marca, modelo, año, precio_base)
        self.num_puertas = num_puertas

    def calcular_alquiler(self, dias):
        return self.precio_base * dias + (self.num_puertas * 10)

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Puertas: {self.num_puertas}")

    def abrir_maletero(self):
        print(f"🔓 {self.marca} {self.modelo}: Maletero abierto.")


class Moto(Vehiculo):
    def __init__(self, marca, modelo, año, precio_base, cilindrada):
        super().__init__(marca, modelo, año, precio_base)
        self.cilindrada = cilindrada

    def calcular_alquiler(self, horas):
        return self.precio_base * horas + (self.cilindrada * 0.5)

    def mostrar_info(self):
        super().mostrar_info()
        print(f"Cilindrada: {self.cilindrada} cc")

    def hacer_caballito(self):
        print(f"🏍️ {self.marca} {self.modelo}: ¡Haciendo caballito!")
