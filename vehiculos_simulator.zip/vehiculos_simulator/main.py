from clases.vehiculos import Vehiculo, Coche, Moto

flota = []

def menu():
    while True:
        print("""
====================================
   SISTEMA DE GESTIÓN DE VEHÍCULOS 
====================================
1. Registrar coche
2. Registrar moto
3. Mostrar flota
4. Encender/Apagar vehículo
5. Calcular alquiler
6. Alquilar vehículo
7. Devolver vehículo
8. Ver estadísticas
9. Dar de baja vehículo
10. Salir
====================================
""")
        opcion = input("Seleccione una opción: ")

        try:
            if opcion == "1":
                marca = input("Marca: ")
                modelo = input("Modelo: ")
                año = int(input("Año: "))
                precio = float(input("Precio base por día: "))
                puertas = int(input("Número de puertas: "))

                if not Vehiculo.validar_año(año) or not Vehiculo.validar_precio(precio) or puertas <= 0:
                    print("❌ Datos inválidos.")
                    continue

                flota.append(Coche(marca, modelo, año, precio, puertas))

            elif opcion == "2":
                marca = input("Marca: ")
                modelo = input("Modelo: ")
                año = int(input("Año: "))
                precio = float(input("Precio base por hora: "))
                cilindrada = int(input("Cilindrada (cc): "))

                if not Vehiculo.validar_año(año) or not Vehiculo.validar_precio(precio) or cilindrada <= 0:
                    print("❌ Datos inválidos.")
                    continue

                flota.append(Moto(marca, modelo, año, precio, cilindrada))

            elif opcion == "3":
                for i, v in enumerate(flota):
                    print(f"{i+1}.")
                    v.mostrar_info()

            elif opcion == "4":
                idx = int(input("Seleccione vehículo: ")) - 1
                accion = input("Encender (E) / Apagar (A): ").upper()
                if accion == "E":
                    flota[idx].encender()
                elif accion == "A":
                    flota[idx].apagar()

            elif opcion == "5":
                idx = int(input("Seleccione vehículo: ")) - 1
                v = flota[idx]
                if isinstance(v, Coche):
                    dias = int(input("Número de días: "))
                    print(f"Costo: {v.calcular_alquiler(dias)}")
                elif isinstance(v, Moto):
                    horas = int(input("Número de horas: "))
                    print(f"Costo: {v.calcular_alquiler(horas)}")

            elif opcion == "6":
                idx = int(input("Seleccione vehículo: ")) - 1
                flota[idx]._disponible = False
                print(f"{flota[idx].marca} {flota[idx].modelo} alquilado.")

            elif opcion == "7":
                idx = int(input("Seleccione vehículo: ")) - 1
                flota[idx]._disponible = True
                print(f"{flota[idx].marca} {flota[idx].modelo} devuelto.")

            elif opcion == "8":
                total = Vehiculo.total_vehiculos()
                encendidos = sum(1 for v in flota if v.encendido)
                coches = sum(1 for v in flota if isinstance(v, Coche))
                motos = sum(1 for v in flota if isinstance(v, Moto))
                print(f"Total: {total} | Encendidos: {encendidos} | Coches: {coches} | Motos: {motos}")

            elif opcion == "9":
                idx = int(input("Seleccione vehículo a dar de baja: ")) - 1
                del flota[idx]

            elif opcion == "10":
                print("👋 Saliendo del sistema...")
                break

            else:
                print("❌ Opción inválida.")

        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    menu()
